var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope) {
	$scope.firstNum = 0;
	$scope.lastNum = 0;
});