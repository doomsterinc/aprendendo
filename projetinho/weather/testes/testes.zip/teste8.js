var app = angular.module('myApp', []);
app.controller ('costCtrl', function($scope) {
	$scope.quantity = 1.99;
	$scope.price = 09.99;
});
