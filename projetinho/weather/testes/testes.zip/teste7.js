var app = angular.module('myApp', []);
app.controller ('personCtrl', function($scope) {
	$scope.lastName = "Ferreira";
});