angular.module("myApp", []);
angular.module("myApp").controller("myCtrl", function($scope) {
	$scope.count = 0;
});