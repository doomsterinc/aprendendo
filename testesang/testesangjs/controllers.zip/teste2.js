angular.module("myApp", []);
angular.module("myApp").controller("personCtrl", function($scope) {
	$scope.firstName = "firstName";
	$scope.lastName = "lastName";
	$scope.myVar = false;
	$scope.toggle = function() {
		$scope.myVar = !$scope.myVar;
	};
});